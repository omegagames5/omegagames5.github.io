Thank you for using MC Server Soft!

If you are having any issues please checkout the FAQ & Documentation
https://mcserversoft.github.io/documentation/faq/
https://mcserversoft.github.io/documentation/
